import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import ModelClasses.*;
import java.util.ArrayList;
import java.util.Vector;

public class OrderInfo extends JPanel 
	implements ActionListener{

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	

	
	// UI elements
	private JPanel ContentsPanel = new JPanel();
	private JPanel CenterPanel = new JPanel();
	
	private Border CenterBorder = BorderFactory.createEmptyBorder(10,10,10,10);
	private Border ContentBorder = BorderFactory.createEmptyBorder(0,0,10,0);
	private Border ListBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1);
	private Box TopBox = Box.createVerticalBox();
	private Box TopRow1Box = Box.createVerticalBox();
	private Box TopRow2Box = Box.createHorizontalBox();
	private Box SrollerBox = Box.createVerticalBox();
	
	private JTextField InputOrderIdField;
	private JTextField InputOrderStatusField;
	
	private JButton SearchButton;
	
	public ArrayList<Order> OrdersForSearch = new ArrayList<Order>();
	public JTable table;
	String[] columnNames = {"OrderId", "OrderStatus", "CustomerName", "TotalItemQty","TotalPrice"};
	public DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
	
	
	
	public OrderInfo() {
		

		// Create a BorderLayout.
		setLayout(new BorderLayout());
		

		ContentsPanel.setBorder(ContentBorder);
		ContentsPanel.setLayout(new BorderLayout());

		// Top region
		JLabel TitleLabel = new JLabel("Welcome! Search for orders ...");		
		TitleLabel.setFont(new Font(Font.DIALOG, Font.BOLD, 18));
		TitleLabel.setAlignmentX(CENTER_ALIGNMENT);
		TopRow1Box.add(TitleLabel);
		TopRow1Box.setBorder(BorderFactory.createEmptyBorder(30,10,0,10));
		TopBox.add(TopRow1Box);		
		TopBox.add(Box.createRigidArea(new Dimension(1,20)));
		
		TopRow2Box.setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
		TopRow2Box.setAlignmentX(LEFT_ALIGNMENT);
		JLabel SearchByOrderIdLabel = new JLabel("By Order ID: ");
		SearchByOrderIdLabel.setAlignmentX(LEFT_ALIGNMENT);
		TopRow2Box.add(SearchByOrderIdLabel);
		TopRow2Box.add(Box.createRigidArea(new Dimension(20,1)));
		InputOrderIdField = new JTextField(20);
		InputOrderIdField.setAlignmentX(LEFT_ALIGNMENT);
		TopRow2Box.add(InputOrderIdField);
		TopRow2Box.add(Box.createRigidArea(new Dimension(20,1)));
		JLabel SearchByOrderStatusLabel = new JLabel("By Order Status: ");
		SearchByOrderStatusLabel.setAlignmentX(LEFT_ALIGNMENT);
		TopRow2Box.add(SearchByOrderStatusLabel);
		TopRow2Box.add(Box.createRigidArea(new Dimension(20,1)));
		InputOrderStatusField = new JTextField(20);
		InputOrderStatusField.setAlignmentX(LEFT_ALIGNMENT);
		TopRow2Box.add(InputOrderStatusField);
		TopRow2Box.add(Box.createRigidArea(new Dimension(20,1)));
		SearchButton = new JButton("Search ...");
		SetSpecificSize(SearchButton, new Dimension(180,30));
		TopRow2Box.add(SearchButton);
		TopRow2Box.add(Box.createRigidArea(new Dimension(20,1)));		
		TopBox.add(TopRow2Box);		
		TopBox.add(Box.createRigidArea(new Dimension(1,20)));		
		ContentsPanel.add(TopBox, BorderLayout.NORTH);
		
		// Center region
		CenterPanel.setBorder(CenterBorder);
		
		/*
		Table data try
		Object[][] data = {
				{"1", "John", "Doe"},
				{"2", "Jane", "Ever"}
		};
		
		String[] columns = {"ID", "First", "Last"};
		DefaultTableModel model = new DefaultTableModel(data,columns);
				*/		
		//String col[] = {"Name","Price"};
		//tableModel = new DefaultTableModel(col, 0);		
		table = new JTable(tableModel);

		SrollerBox.setBorder(ListBorder);
		JScrollPane OrdersScroller = new JScrollPane(table);
		OrdersScroller.setAlignmentX(LEFT_ALIGNMENT);
		OrdersScroller.setVerticalScrollBarPolicy(OrdersScroller.VERTICAL_SCROLLBAR_ALWAYS);
		OrdersScroller.setHorizontalScrollBarPolicy(OrdersScroller.HORIZONTAL_SCROLLBAR_ALWAYS);
		SetSpecificSize(OrdersScroller, new Dimension(700, 420));
		SrollerBox.add(OrdersScroller);
		CenterPanel.add(SrollerBox);
		CenterPanel.add(Box.createRigidArea(new Dimension(10,1)));
		
		ContentsPanel.add(CenterPanel, BorderLayout.CENTER);
		
		SearchButton.addActionListener(this);
		
		add(ContentsPanel);
		
		setVisible(true);

	}
	
	private void SetSpecificSize(JComponent c, Dimension d) {
		c.setMinimumSize(d);
		c.setPreferredSize(d);
		c.setMaximumSize(d);
	}
	
	public void InitModelForOrdersInfoTab() {
		DisplayTable(OrdersForSearch);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == SearchButton) {
			SearchOrdersByInputs();
			return;
		}		
	}
	private void SearchOrdersByInputs() {
		//System.out.println("Search");	
		String orderId = InputOrderIdField.getText();
		String orderStatus = InputOrderStatusField.getText();
		if ((orderId == null || orderId.isEmpty() || orderId.isBlank()) &&
				(orderStatus == null || orderStatus.isEmpty() || orderStatus.isBlank())) {
			InitModelForOrdersInfoTab();
			return;
		}
		
		Integer orderIdInt = 0;
		if ((orderId == null || orderId.isEmpty() || orderId.isBlank())){
			
		}
		else {
			 orderIdInt = Integer.parseInt(orderId);
		}
		
		ArrayList<Order> result = new ArrayList<Order>();
		for(Order o: OrdersForSearch) {
			if ((o.GetOrderId() == orderIdInt) || (o.GetOrderStatus().equals(orderStatus))){
				result.add(o);
			}
		}
		DisplayTable(result);
	}
	
	private void DisplayTable(ArrayList<Order> orderList) {
		if (orderList == null || orderList.size()==0)
			return;
		
		tableModel =  new DefaultTableModel(columnNames, 0); 
		for(Order o: orderList) {
			//{"OrderId", "OrderStatus", "CustomerName", "TotalItemQty","TotalPrice"};
			Vector<Object> newRowData = new Vector<>();
            newRowData.add("" + o.GetOrderId());
            newRowData.add("" + o.GetOrderStatus()); 
            newRowData.add(o.GetCustomerName());
            newRowData.add("" + o.GetAllItemQty());
            newRowData.add("" + o.GetAllItemPrice());
            tableModel.addRow(newRowData);
		}
		table.setModel(tableModel);
	}
}
