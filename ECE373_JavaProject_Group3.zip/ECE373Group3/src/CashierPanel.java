

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.Border;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import ModelClasses.Item;
import ModelClasses.MenuItem;
import ModelClasses.Order;

public class CashierPanel extends JPanel 
	implements ActionListener, ItemListener, ListSelectionListener {

	private static final long serialVersionUID = 1L;
	
	// UI elements
	private Border CenterBorder = BorderFactory.createEmptyBorder(10,10,10,10);
	private Border ContentBorder = BorderFactory.createEmptyBorder(0,0,10,0);
	private Border ListBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1);
	private Border WestBorder = BorderFactory.createEmptyBorder(10,50,10,10);
	
	private Box TopBox = Box.createVerticalBox();
	private Box CenterBox = Box.createVerticalBox();
	private Box BottomBox = Box.createVerticalBox();
	private Box OrderListBox = Box.createVerticalBox();
	private Box OrderBox = Box.createVerticalBox();
	private Box ReceiptBox = Box.createVerticalBox();
	private Box ButtonBox = Box.createVerticalBox();

	
	private JPanel ContentsPanel;
	private JPanel TopPanel;
	private JPanel WestPanel;
	private JPanel CenterPanel;
	private JPanel EastPanel;
	private JPanel BottomPanel;
	
	private JButton ReadyToCookButton;
	private JButton PrintReceiptButton;
	private JButton CancelOrderButton;
	
	private JLabel OrdersLabel = new JLabel("Orders:");
	private JLabel SelectedOrderLabel = new JLabel("Selected Order:");
	private JLabel SelectedOrderInfo = new JLabel();
	private JLabel ReceiptLabel = new JLabel("Receipt:");
	private JLabel ReceiptInfo = new JLabel();
	private JLabel SelectedOrderStatusLabel = new JLabel("Selected Order Status:");
	private JLabel SelectedOrderStatusInfo = new JLabel();
	
	public JFrame dialogFrame = new JFrame();
			
	private JList<String> OrderList;
	public DefaultListModel<String> DOrderList = new DefaultListModel<>();
	private JList<String> OrderInfoList;
	public DefaultListModel<String> DOrderInfoList = new DefaultListModel<>();
	private JList<String> ReceiptInfoList;
	public DefaultListModel<String> DReceiptInfoList = new DefaultListModel<>();

	
	// Models
	public ArrayList<Order> CashierPanelOrders = new ArrayList<>();
	public Order SelectedOrder = new Order();
	

	/**
	 * Create the panel.
	 */
	public CashierPanel() {
		
		// Create a BorderLayout.
		setLayout(new BorderLayout());	
		
		// Main contents
		ContentsPanel = new JPanel();
		ContentsPanel.setBorder(ContentBorder);
		ContentsPanel.setLayout(new BorderLayout());
		
		// Top region
		JLabel TitleLabel = new JLabel("Welcome!");
		TitleLabel.setFont(new Font(Font.DIALOG, Font.BOLD, 18));
		TitleLabel.setAlignmentX(CENTER_ALIGNMENT);
		TopBox.add(TitleLabel);
		TopBox.add(Box.createRigidArea(new Dimension(1,10)));
		TopPanel = new JPanel();
		TopPanel.setBorder(ContentBorder);
		TopPanel.add(TopBox);
		ContentsPanel.add(TopPanel, BorderLayout.NORTH);
		
		// Center region
		PopulateOrderList();
		
		WestPanel = new JPanel();
		WestPanel.setBorder(WestBorder);
		WestPanel.setLayout(new BoxLayout(WestPanel, BoxLayout.Y_AXIS));

		OrdersLabel.setAlignmentX(LEFT_ALIGNMENT);
		OrderList = new JList<String>(DOrderList);
		OrderList.setAlignmentX(LEFT_ALIGNMENT);
		OrderList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		OrderList.setBorder(ListBorder);
		JScrollPane OrderListScroller = new JScrollPane(OrderList);
		OrderListScroller.setAlignmentX(LEFT_ALIGNMENT);
		OrderListScroller.setVerticalScrollBarPolicy(OrderListScroller.VERTICAL_SCROLLBAR_ALWAYS);
		SetSpecificSize(OrderListScroller, new Dimension(350, 230));
		OrderListBox.add(OrdersLabel);
		OrderListBox.add(OrderListScroller);
		WestPanel.add(OrderListBox);
		WestPanel.add(Box.createRigidArea(new Dimension(1, 10)));
				
		SelectedOrderLabel.setAlignmentX(LEFT_ALIGNMENT);
		SelectedOrderInfo.setAlignmentX(LEFT_ALIGNMENT);
		//JScrollPane OrderScroller = new JScrollPane(SelectedOrderInfo);
		OrderInfoList = new JList<String>(DOrderInfoList);
		OrderInfoList.setAlignmentX(LEFT_ALIGNMENT);
		//OrderInfoList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		OrderInfoList.setBorder(ListBorder);
		JScrollPane OrderScroller = new JScrollPane(OrderInfoList);
		OrderScroller.setAlignmentX(LEFT_ALIGNMENT);
		OrderScroller.setVerticalScrollBarPolicy(OrderScroller.VERTICAL_SCROLLBAR_ALWAYS);
		SetSpecificSize(OrderScroller, new Dimension(350, 230));
		OrderBox.add(SelectedOrderLabel);
		OrderBox.add(OrderScroller);		
		
		SelectedOrderStatusLabel.setAlignmentX(LEFT_ALIGNMENT);
		SelectedOrderStatusInfo.setAlignmentX(LEFT_ALIGNMENT);
		OrderBox.add(SelectedOrderStatusLabel);
		OrderBox.add(SelectedOrderStatusInfo);
		WestPanel.add(OrderBox);
		ContentsPanel.add(WestPanel, BorderLayout.WEST);
		
		CenterPanel = new JPanel();
		CenterPanel.setBorder(CenterBorder);
		ReadyToCookButton = new JButton("Ready to Cook >");
		PrintReceiptButton = new JButton("Print Receipt >>");
		CancelOrderButton = new JButton("< Cancel Order");
		SetSpecificSize(ReadyToCookButton, new Dimension(180,30));
		SetSpecificSize(PrintReceiptButton, new Dimension(180,30));
		SetSpecificSize(CancelOrderButton, new Dimension(180,30));		
		ButtonBox.add(ReadyToCookButton);
		ButtonBox.add(Box.createRigidArea(new Dimension(1,20)));
		ButtonBox.add(PrintReceiptButton);
		ButtonBox.add(Box.createRigidArea(new Dimension(1,100)));
		ButtonBox.add(CancelOrderButton);		
		CenterPanel.add(ButtonBox);
		CenterPanel.add(Box.createRigidArea(new Dimension(30, 1)));
		
		ReceiptLabel.setAlignmentX(LEFT_ALIGNMENT);
		ReceiptInfo.setAlignmentX(LEFT_ALIGNMENT);
		//JScrollPane ReceiptScroller = new JScrollPane(ReceiptInfo);
		ReceiptInfoList = new JList<String>(DReceiptInfoList);
		ReceiptInfoList.setAlignmentX(LEFT_ALIGNMENT);
		ReceiptInfoList.setBorder(ListBorder);
		JScrollPane ReceiptScroller = new JScrollPane(ReceiptInfoList);
		ReceiptScroller.setAlignmentX(LEFT_ALIGNMENT);		
		ReceiptScroller.setVerticalScrollBarPolicy(ReceiptScroller.VERTICAL_SCROLLBAR_ALWAYS);
		SetSpecificSize(ReceiptScroller, new Dimension(350, 500));
		ReceiptBox.add(ReceiptLabel);
		ReceiptBox.add(ReceiptScroller);
		CenterPanel.add(ReceiptBox);
				
		ContentsPanel.add(CenterPanel, BorderLayout.CENTER);
		

		ReadyToCookButton.addActionListener(this);
		PrintReceiptButton.addActionListener(this);
		CancelOrderButton.addActionListener(this);

		OrderList.addListSelectionListener(this);
		
		
		add(ContentsPanel);
		
		dialogFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dialogFrame.setSize(200, 150);

	}

	public void PopulateOrderList() {
		DOrderList.clear();
		if (CashierPanelOrders == null)
			return;
		
	    for (Order item : CashierPanelOrders) {
	    	DOrderList.addElement(item.GetOrderIdStatus());
	    }
	    //OrderList = new JList<String>(DOrderList);
	    
	}
	public void ClearSelectedData() {
		SelectedOrder = new Order();
		DOrderInfoList.clear();
		DReceiptInfoList.clear();
		SelectedOrderStatusInfo.setText("");
	}
	
	private void SetSpecificSize(JComponent c, Dimension d) {
		c.setMinimumSize(d);
		c.setPreferredSize(d);
		c.setMaximumSize(d);
	}
	
	
	
	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
		Object source = e.getSource();
		if (source == OrderList || source.equals(OrderList) ||
				source.getClass() == OrderList.getClass()) {
			DisplaySelectedOrder();
			return;
		}
	}
	
	public void DisplaySelectedOrder() {
	    String selectedDisplayOrder = OrderList.getSelectedValue();
	    if (selectedDisplayOrder == null)
	        return;

	    int orderIdEndIdx = selectedDisplayOrder.indexOf("[");
	    String orderId = selectedDisplayOrder.substring(8, orderIdEndIdx - 1);
	    this.SelectedOrder = MainWindow.GetOrderById(orderId);

	    DOrderInfoList.clear();


	    ArrayList<String> itemNames = new ArrayList<>();
	    ArrayList<Integer> itemQty = new ArrayList<>();

	    for (Item i : SelectedOrder.GetAllItems()) {
	        String info = i.GetItemNameQty();   

	    
	        String name = info;
	        int nameStart = info.indexOf("Name=");
	        int qtyPos = info.indexOf(", Qty");
	        if (nameStart >= 0 && qtyPos > nameStart) {
	            nameStart += "Name=".length();
	            name = info.substring(nameStart, qtyPos);
	        }

	      
	        int idx = itemNames.indexOf(name);
	        if (idx == -1) {
	            itemNames.add(name);
	            itemQty.add(1);
	        } else {
	            itemQty.set(idx, itemQty.get(idx) + 1);
	        }
	    }


	    for (int i = 0; i < itemNames.size(); i++) {
	        String line = "food: Name=" + itemNames.get(i) + ", Qty=" + itemQty.get(i);
	        DOrderInfoList.addElement(line);
	    }

	    SelectedOrderStatusInfo.setText(SelectedOrder.GetOrderStatus());
	}




	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
		
	}
	



	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object source = e.getSource();
		if (source == ReadyToCookButton) {
			SetOrderToCook();
			return;
		}
		if (source == PrintReceiptButton) {
			PrintReceipt();
			return;
		}
		if (source == CancelOrderButton) {
			CancelOrder();
			return;
		}
	}
	
	public void SetOrderToCook() {
		
		String orderStatus = SelectedOrder.GetOrderStatus();
		if (orderStatus.equals("Paid")) {
		
			this.SelectedOrder.SetOrderStatus("Ready to cook");
			PopulateOrderList();
			SelectedOrderStatusInfo.setText(SelectedOrder.GetOrderStatus());
		}
		else {
			JOptionPane.showMessageDialog(dialogFrame, 
					"Sorry, only 'Paid' order can be set to 'Ready to cook'.", 
					"Warning", JOptionPane.WARNING_MESSAGE);
		}
		
	}
	public void PrintReceipt() {
	    DReceiptInfoList.clear();

	
	    ArrayList<String> itemNames = new ArrayList<>();  
	    ArrayList<Integer> itemQty = new ArrayList<>();

	    for (Item i : SelectedOrder.GetAllItems()) {
	        String info = i.GetNamePriceInfo();          

	        int idx = itemNames.indexOf(info);
	        if (idx == -1) {
	            itemNames.add(info);
	            itemQty.add(1);
	        } else {
	            itemQty.set(idx, itemQty.get(idx) + 1);
	        }
	    }

	  
	    for (int i = 0; i < itemNames.size(); i++) {
	        String line = itemNames.get(i);              
	        int qty = itemQty.get(i);
	        if (qty > 1) {
	            line = line + "  x " + qty;               
	        }
	        DReceiptInfoList.addElement(line);
	    }

	
	    DReceiptInfoList.addElement("---------------------------------");
	    DReceiptInfoList.addElement("Total Price:   $" + SelectedOrder.GetAllItemPrice());

	 
	    String orderStatus = SelectedOrder.GetOrderStatus();
	    if (orderStatus.equals("Cancelled")) {
	        DReceiptInfoList.addElement("                   -   $" + SelectedOrder.GetAllItemPrice());
	        DReceiptInfoList.addElement("---------------------------------");
	        DReceiptInfoList.addElement("Total Price:   $" + SelectedOrder.GetTotalPrice());
	    }
	}

	public void CancelOrder() {
		
		if (SelectedOrder == null || SelectedOrder.GetOrderId() == -1) {
			JOptionPane.showMessageDialog(dialogFrame, 
					"No order is selected.", 
					"Information", JOptionPane.INFORMATION_MESSAGE);
			
		} 
		else if(SelectedOrder.GetOrderIdStatus().contains("Picked up")) {
			JOptionPane.showMessageDialog(dialogFrame, "Can not cancel a Picked up order", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else {
			int selectedOrderId = SelectedOrder.GetOrderId();
			// Display a confirmation dialog
	        int result = JOptionPane.showConfirmDialog(dialogFrame, 
	        		"Do you want to cancel the order (OrderId=" 
	                    + Integer.toString(selectedOrderId) + ") ?", 
	        		"Confirmation", JOptionPane.YES_NO_OPTION);
	        if (result == JOptionPane.YES_OPTION) {
				this.SelectedOrder.SetOrderStatus("Cancelled");
				this.SelectedOrder.SetTotalPrice(0.0);
				PopulateOrderList();
				SelectedOrderStatusInfo.setText(SelectedOrder.GetOrderStatus());
	        } else {
	            System.out.println("User chose 'not cancel the order'.");
	        }
		}
	}
	
}
