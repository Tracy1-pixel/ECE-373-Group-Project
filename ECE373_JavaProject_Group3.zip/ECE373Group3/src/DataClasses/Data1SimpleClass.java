package DataClasses;

import java.util.*;
import ModelClasses.*;

public class Data1SimpleClass {
	
	public Restaurant MainRestaurant;
	public ArrayList<Employee> Employees;
	public ArrayList<Customer> Customers;
	public ArrayList<MenuItem> FoodMenu;
	
	public Data1SimpleClass() {
		MainRestaurant = new Restaurant();
		Employees = new ArrayList<Employee>();
		Customers = new ArrayList<Customer>();
		FoodMenu = new ArrayList<MenuItem>();
	}
	
	public void SetupData1() {
		
		MainRestaurant.SetRestaurantId(1);
		MainRestaurant.SetRestaurantName("Main Restaurant");
		MainRestaurant.SetRestaurantLocation("Tucson, AZ");
		ArrayList<String> openHours = new ArrayList<String>();
		openHours.add("Monday:\t  8AM - 8PM");
		openHours.add("Tuesday:\t  8AM - 8PM");
		openHours.add("Wednesday:\t  8AM - 8PM");
		openHours.add("Thursday:\t  8AM - 8PM");
		openHours.add("Friday:\t  8AM - 7PM");
		openHours.add("Saturday:\t10AM - 7PM");
		openHours.add("Sunday:\t11AM - 3PM");
		MainRestaurant.SetStoreHours(openHours);
		
		Manager Manager1 = new Manager();
		Manager1.SetEmployId(100);
		Manager1.SetName("Bob");
		Employees.add(Manager1);
		
		Cashier Cashier1 = new Cashier();
		Cashier1.SetEmployId(101);
		Cashier1.SetName("Smith");
		Employees.add(Cashier1);
		
		Cooker Cooker1 = new Cooker();
		Cooker1.SetEmployId(102);
		Cooker1.SetName("Chief");
		Employees.add(Cooker1);
		
		Customer Customer1 = new Customer("Joe");
		Customers.add(Customer1);
		
		//MenuItem(String name, String dsrpt, double price, String type)
		MenuItem MenuItem11 = new MenuItem("Hamburger", "Standard Burger", 3.00, "food");
		FoodMenu.add(MenuItem11);
		MenuItem MenuItem12 = new MenuItem("CheeseBurger", "Cheese Burger", 3.50, "food");
		FoodMenu.add(MenuItem12);
		MenuItem MenuItem13 = new MenuItem("VeggieBurger", "Veggie Burger", 3.50, "food");
		FoodMenu.add(MenuItem13);
		MenuItem MenuItem14 = new MenuItem("ButterBurger", "Butter Burger", 3.50, "food");
		FoodMenu.add(MenuItem14);
		MenuItem MenuItem15 = new MenuItem("ChickenBurger", "Chichen Burger", 3.50, "food");
		FoodMenu.add(MenuItem15);
		MenuItem MenuItem16 = new MenuItem("Fries", "Fries", 1.50, "food");
		FoodMenu.add(MenuItem16);
		MenuItem MenuItem17 = new MenuItem("Nuggets", "Chichen Nuggets", 2.20, "food");
		FoodMenu.add(MenuItem17);
		MenuItem MenuItem21 = new MenuItem("Tea", "Iced Tea", 1.50, "drink");
		FoodMenu.add(MenuItem21);
		MenuItem MenuItem22 = new MenuItem("Soda", "Soda", 1.50, "drink");
		FoodMenu.add(MenuItem22);
		MenuItem MenuItem23 = new MenuItem("Water", "Water with ice", 0.00, "drink");
		FoodMenu.add(MenuItem23);
				
		MainRestaurant.SetEmployees(Employees);
		MainRestaurant.SetFoodMenu(FoodMenu);
		
	}
	
	public Restaurant GetRestaurantData() {
		return MainRestaurant;
	}

}
