package DataClasses;

import java.util.*;
import ModelClasses.*;

public class UnitTests {

	public static void main(String[] args) 
	{
		System.out.println("Unit Testing ...");
		System.out.println("");
		
		// Testing Order.java
		Order order1 = new Order();
		order1.SetCustomer("customer1");
		MenuItem MenuItem11 = new MenuItem("Hamburger", "Standard Burger", 3.00, "food");
		MenuItem MenuItem21 = new MenuItem("Tea", "Iced Tea", 1.50, "drink");
		order1.AddToAllItems(MenuItem11);
		order1.AddToAllItems(MenuItem21);
		
		System.out.println("Testing GetOrderAllItemsInfo()");
		System.out.println(order1.GetOrderAllItemsInfo());
		System.out.println("Testing GetAllItemPrice()");
		System.out.println("Total Price = $" + order1.GetAllItemPrice());
	}
}
