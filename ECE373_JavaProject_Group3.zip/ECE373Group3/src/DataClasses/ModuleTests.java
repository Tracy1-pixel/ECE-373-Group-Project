package DataClasses;

import java.util.*;
import ModelClasses.*;

public class ModuleTests {

	public static void main(String[] args) 
	{
		System.out.println("Module Testing ...");
		System.out.println("");
		
		// Testing order list functions
		Order order1 = new Order();
		order1.SetOrderId(1);
		order1.SetCustomer("customer1");
		MenuItem MenuItem11 = new MenuItem("Hamburger", "Standard Burger", 3.00, "food");
		MenuItem MenuItem21 = new MenuItem("Tea", "Iced Tea", 1.50, "drink");		
		order1.AddToAllItems(MenuItem11);
		order1.AddToAllItems(MenuItem21);
		order1.SetOrderStatus("Paid");
		
		Order order2 = new Order();
		order2.SetOrderId(2);
		order2.SetCustomer("customer2");		
		MenuItem MenuItem12 = new MenuItem("Soda", "Soda", 1.50, "drink");
		MenuItem MenuItem22 = new MenuItem("Fries", "Fries", 1.50, "food");
		order2.AddToAllItems(MenuItem12);
		order2.AddToAllItems(MenuItem22);
		order2.SetOrderStatus("Preparing");
		
		ArrayList<Order> RestaurantOrders = new ArrayList<Order>();
		
		System.out.println("Added Order 1:");
		RestaurantOrders.add(order1);		
		for(Order i: RestaurantOrders) {
			System.out.println("Order ID=" + i.GetOrderId() + ", Status=" + i.GetOrderStatus());
		}
		
		System.out.println("");
		System.out.println("Added Order 2:");
		RestaurantOrders.add(order2);
		for(Order i: RestaurantOrders) {
			System.out.println("Order ID=" + i.GetOrderId() + ", Status=" + i.GetOrderStatus());
		}
		
	}
}
