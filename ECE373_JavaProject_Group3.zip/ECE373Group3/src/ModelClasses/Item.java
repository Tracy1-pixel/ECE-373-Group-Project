package ModelClasses;

public class Item {
	protected String ItemName;
	protected double ItemPrice;
	protected String ItemType;
	protected int ItemQty;
	
	public Item() {
		ItemName = "";
		ItemPrice = 0.0;
		ItemType = "";
		ItemQty = 1;
	}
	
	public String GetItemName() {
		return ItemName;
	}
	public void SetItemName(String name) {
		ItemName = name;
	}
	public double GetItemPrice() {
		return ItemPrice;
	}
	public void SetItemPrice(double price) {
		ItemPrice = price;
	}
	public String GetItemType() {
		return ItemType;
	}
	public void SetItemType(String type) {
		ItemType = type;
	}
	public int GetItemQty() {
		return ItemQty;
	}
	public void SetItemQty(int qty) {
		ItemQty = qty;
	}
	
	public String GetNamePriceInfo() {
		return "" + ItemName + " ($" + ItemPrice +")";
	}
	public String GetItemInfo() {
		return "" + ItemType + ": Name=" + ItemName + " ($" + ItemPrice +"), Qty=" + ItemQty;
	}
	public String GetItemNameQty() {
		return "" + ItemType + ": Name=" + ItemName + ", Qty=" + ItemQty;
	}

}
