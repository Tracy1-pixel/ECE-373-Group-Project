package ModelClasses;


public class Customer extends Person{

	private String ContactPhoneNumber;
	private Order CurrentOrder;
	private double CurrentFee;
	
	public Customer() {
		super();
		
		CurrentOrder = new Order();
		CurrentFee = 0.0;
		ContactPhoneNumber = "";
	}
	public Customer(String name) {
		
		super(name);

		CurrentOrder = new Order();
		CurrentFee = 0.0;
		ContactPhoneNumber = "";
		
	}
	
	public Order GetCurrentOrder() {
		return CurrentOrder;
	}
	public void SetCurrentOrder(Order cur) {
		CurrentOrder = cur;
	}
	public double GetCurrentFee() {
		return CurrentFee;
	}
	public void SetCurrentFee(double fee) {
		CurrentFee = fee;
	}
	public String GetContactPhoneNumber() {
		return ContactPhoneNumber;
	}
	public void SetContactPhoneNumber(String phoneNum) {
		ContactPhoneNumber = phoneNum;
	}
}
