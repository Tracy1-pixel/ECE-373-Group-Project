package ModelClasses;
import java.util.*;

public class Cooker extends Employee{
	
	public Cooker() {
		super();
	}

	public Order GetOrderToCook(ArrayList<Order> orders) {
		Order theOrder = new Order();
		// add implementation
		return theOrder;
	}
	
	public boolean SetOrderStatus(Order order, String status) {
		order.SetOrderStatus(status);
		return true;
	}	
}
