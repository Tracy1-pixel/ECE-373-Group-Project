package ModelClasses;

public class Person {
	
	protected String Name;
	
	public Person() {
		Name = "";
	}
	public Person(String name) {
		SetName(name);
	}
	
	public String GetName() {
		return Name;
	}
	public void SetName(String name) {
		Name = name;
	}

}
