package ModelClasses;

public class Employee extends Person{
	
	protected int Id;
	protected String JobType;
	
	public Employee() {
		super();
		
		Id = -1;
		JobType = "";
	}
	
	public int GetEmployId() {
		return Id;
	}
	public void SetEmployId(int id) {
		Id = id;
	}
	public String GetJobType() {
		return JobType;
	}
	public void SetJobType(String type) {
		JobType = type;
	}

}
