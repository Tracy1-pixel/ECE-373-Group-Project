package ModelClasses;
import java.time.*;

public class Payment {
	
	private int PaymentId;
	private String PayMethod;
	private double PayAmount;
	private String PayStatus;
	private LocalDateTime PayTime;
	private String AuthCode;
	
	public Payment() {
		PaymentId = -1;
		PayMethod = "";
		PayAmount = 0.0;
		PayStatus = "";
		PayTime = LocalDateTime.now();
		AuthCode = "";
	}
	
	
	public int GetPaymentId() {
		return PaymentId;
	}
	public void SetPaymentId(int id) {
		PaymentId = id;
	}
	public String GetPayMethod() {
		return PayMethod;
	}
	public void SetPayMethod(String method) {
		PayMethod = method;
	}
	public double GetPayAmount() {
		return PayAmount;
	}
	public void SetPayAmount (double amount) {
		PayAmount = amount;
	}
	public String GetPayStatus() {
		return PayStatus;
	}
	public void SetPayStatus(String status) {
		PayStatus = status;
	}
	public LocalDateTime GetPayTime() {
		return PayTime;
	}
	public void SetPayTime(LocalDateTime time) {
		PayTime = time;
	}
	public String GetAuthCode() {
		return AuthCode;
	}
	public void SetAuthCode(String code) {
		AuthCode = code;
	}
	
	public boolean Refund() {
		//Need implementation
		return true;
	}
	
	public boolean Pay() {
		//Need implementation
		return true;
	}
	
	public boolean Authorize() {
		//Need implementation
		return true;
	}
	
	public boolean Capture() {
		//Need implementation
		return true;
	}

}
