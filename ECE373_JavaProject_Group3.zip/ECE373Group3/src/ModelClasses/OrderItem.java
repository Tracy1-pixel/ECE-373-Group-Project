package ModelClasses;

public class OrderItem extends Item {
	
	private String ShortDescription;
	
	public OrderItem() {
		super();
		
		ShortDescription = "";
	}
	
	public String GetShortDescription() {
		return ShortDescription;
	}
	public void SetShortDescription(String shortDes) {
		ShortDescription = shortDes;
	}

}
