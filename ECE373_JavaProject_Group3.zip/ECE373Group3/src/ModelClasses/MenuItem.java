package ModelClasses;

public class MenuItem extends Item{
	
	private String Description;
	private String LongDescription;
	
	public MenuItem() {
		super();
		
		Description = "";
		LongDescription = "";
	}
	public MenuItem(String name, String dsrpt, double price, String type) {
		ItemName = name;
		Description = dsrpt;
		LongDescription = dsrpt;
		ItemPrice = price;
		ItemType = type;
	}

	public String GetDescription() {
		return Description;
	}
	public void SetDescription(String description) {
		Description = description;
	}
	public String GetLongDescription() {
		return LongDescription;
	}
	public void SetLongDescription(String longDes) {
		LongDescription = longDes;
	}
	
}
