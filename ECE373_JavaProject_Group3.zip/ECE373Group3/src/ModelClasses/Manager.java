package ModelClasses;

public class Manager extends Employee {
	
	public Manager() {
		super();
		
	}
	
	// has super admin powers
	
	public boolean WaveOrder(Order order) {
		// add implementation
		return true;
	}
	
	public boolean CancelOrder(Order order) {
		// add implementation
		return true;
	}
	
	public boolean RefundOrder(Order order) {
		// add implementation
		return true;
	}
	
	public boolean SetOrderStatus(Order order, String status) {
		order.SetOrderStatus(status);
		return true;
	}

}
