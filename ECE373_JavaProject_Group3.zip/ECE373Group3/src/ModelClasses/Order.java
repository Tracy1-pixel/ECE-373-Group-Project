package ModelClasses;

import java.util.*;

import javax.swing.DefaultListModel;

import java.time.*;

public class Order {
	
	private int OrderId;
	private ArrayList<OrderItem> FoodItems;
	private ArrayList<OrderItem> DrinkItems;
	private ArrayList<Item> AllItems;
	private double TotalPrice;
	private LocalDateTime CreatedTime;
	private String OrderStatus;
	private String CustomerName;
	private Payment Payment;
	
	public Order() {
		OrderId = -1;
		FoodItems = new ArrayList<OrderItem>();
		DrinkItems = new ArrayList<OrderItem>();
		AllItems = new ArrayList<Item>();
		TotalPrice = 0.0;
		CreatedTime = LocalDateTime.now();
		OrderStatus = "";
		CustomerName = "";
		Payment = new Payment();
	}
	
	public Order(Order copy) {
		// deep copy
		OrderId = copy.OrderId;
		TotalPrice = copy.TotalPrice;
		CreatedTime = copy.CreatedTime;
		OrderStatus = copy.OrderStatus;
		CustomerName = copy.CustomerName;		

		AllItems = new ArrayList<Item>();
		for (Item i: copy.GetAllItems()) {
			AllItems.add(i);
		}
		FoodItems = new ArrayList<OrderItem>();
		for (OrderItem i: copy.GetFoodItems()) {
			FoodItems.add(i);
		}
		DrinkItems = new ArrayList<OrderItem>();
		for (OrderItem i: copy.GetDrinkItems()) {
			DrinkItems.add(i);
		}
		
		// TODO: deep copy Payment Object
		Payment = copy.Payment;
	}
	
	
	public int GetOrderId() {
		return OrderId;
	}
	public void SetOrderId(int id) {
		OrderId = id;
	}
	public ArrayList<OrderItem> GetFoodItems(){
		return FoodItems;
	}
	public void SetFoodItems(ArrayList<OrderItem> items) {
		FoodItems = items;
	}
	public ArrayList<OrderItem> GetDrinkItems(){
		return DrinkItems;
	}
	public void SetDrinkItems(ArrayList<OrderItem> items) {
		DrinkItems = items;
	}
	public ArrayList<Item> GetAllItems(){
		return AllItems;
	}
	public void SetAllItems(ArrayList<Item> items) {
		AllItems = items;
	}
	public void AddToAllItems(Item item) {
		AllItems.add(item);
	}
	public void DeleteFromAllItems(Item item) {
		AllItems.remove(item);
	}
	public double GetTotalPrice() {
		return TotalPrice;
	}
	public void SetTotalPrice(double price) {
		TotalPrice = price;
	}
	public LocalDateTime GetCreatedTime() {
		return CreatedTime;
	}
	public void SetCreatedTime(LocalDateTime time) {
		CreatedTime = time;
	}
	public String GetOrderStatus() {
		return OrderStatus;
	}
	public void SetOrderStatus(String status) {
		OrderStatus = status;
	}
	public String GetCustomerName() {
		return CustomerName;
	}
	public void SetCustomer(String name) {
		CustomerName = name;
	}
	public Payment GetPayment() {
		return Payment;
	}
	public void SetPayment(Payment payment) {
		Payment = payment;
	}
	
	
	public double GetAllItemPrice() {
		double total = 0.0;
		for(Item i: AllItems) {
			total = total + i.GetItemPrice();
		}
		return total;
	}
	
	public String GetOrderIdStatus() {
		return "OrderID=" + OrderId + " [" + OrderStatus + "]";
	}
	public String GetOrderAllItemsInfo() {
		if (AllItems == null)
			return "";
		
		String resultStr = "";
		for (Item i: AllItems) {
			resultStr = resultStr + i.GetNamePriceInfo() + "\n";
		}				
		return resultStr;
	}
	public DefaultListModel<String> GetOrderAllItemsNameQty() {
		DefaultListModel<String> itemNameQtyList = new DefaultListModel<String>();
		if (AllItems == null)
			return itemNameQtyList;
		
		int idx = 0;
		for (Item i: AllItems) {
			//itemNameQtyList.add(idx, i.GetItemNameQty());
			//idx = idx+1;
			itemNameQtyList.addElement(i.GetItemNameQty());
		}				
		return itemNameQtyList;
	}
	
	public Integer GetAllItemQty() {
		Integer total = 0;
		for(Item i: AllItems) {
			total = total + i.GetItemQty();
		}
		return total;
	}

}
