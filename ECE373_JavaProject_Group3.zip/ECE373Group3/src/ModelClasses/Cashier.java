package ModelClasses;

public class Cashier extends Employee{
	
	public Cashier() {
		super();
		
	}
	
	public boolean CancelOrder(Order order) {
		// add implementation
		return true;
	}
	
	public boolean RefundOrder(Order order) {
		// add implementation
		return true;
	}
	
	public boolean SetOrderStatus(Order order, String status) {
		order.SetOrderStatus(status);
		return true;
	}
}
