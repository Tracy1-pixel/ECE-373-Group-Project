package ModelClasses;

import java.util.*;

public class Restaurant {
	
	private int RestaurantId;
	private String RestaurantName;
	private String RestaurantLocation;
	private ArrayList<Order> Orders;
	private ArrayList<MenuItem> FoodMenu;
	private ArrayList<MenuItem> DrinkMenu;
	private ArrayList<Employee> Employees;
	private ArrayList<String> StoreHours;
	
	public Restaurant() {
		RestaurantId = -1;
		RestaurantName = "";
		RestaurantLocation = "";
		Orders = new ArrayList<Order>();
		FoodMenu = new ArrayList<MenuItem>();
		DrinkMenu = new ArrayList<MenuItem>();
		Employees = new ArrayList<Employee>();
		StoreHours = new ArrayList<String>();
	}
	
	public int GetRestaurantId() {
		return RestaurantId;
	}
	public void SetRestaurantId(int id) {
		RestaurantId = id;
	}
	public String GetRestaurantName() {
		return RestaurantName;
	}
	public void SetRestaurantName(String name) {
		RestaurantName = name;
	}
	public String GetRestaurantLocation() {
		return RestaurantLocation;
	}
	public void SetRestaurantLocation(String location) {
		RestaurantLocation = location;
	}
	public ArrayList<Order> GetOrders(){
		return Orders;
	}
	public void SetOrders(ArrayList<Order> orders) {
		Orders = orders;
	}
	public ArrayList<MenuItem> FoodMenu(){
		return FoodMenu;
	}
	public void SetFoodMenu(ArrayList<MenuItem> foods) {
		FoodMenu = foods;
	}
	public ArrayList<MenuItem> GetDrinkMenu(){
		return DrinkMenu;
	}
	public void SetDrinkMenu(ArrayList<MenuItem> drinks) {
		DrinkMenu = drinks;
	}
	public ArrayList<Employee> GetEmployees(){
		return Employees;
	}
	public void SetEmployees(ArrayList<Employee> employees) {
		Employees = employees;
	}
	public ArrayList<String> GetStoreHours(){
		return StoreHours;
	}
	public void SetStoreHours(ArrayList<String> Hrs) {
		StoreHours = Hrs;
	}

}
