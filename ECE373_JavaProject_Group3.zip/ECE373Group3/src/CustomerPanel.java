import ModelClasses.*;
import ModelClasses.MenuItem;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


public class CustomerPanel extends JPanel 
	implements ActionListener, ItemListener, ListSelectionListener {

	private static final long serialVersionUID = 1L;
		
	// UI elements
	private Border CenterBorder = BorderFactory.createEmptyBorder(10,10,10,10);
	private Border ContentBorder = BorderFactory.createEmptyBorder(0,0,10,0);
	private Border ListBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1);
	
	private Box TopBox = Box.createVerticalBox();
	private Box TopRow1Box = Box.createVerticalBox();
	private Box TopRow2Box = Box.createVerticalBox();
	private Box ButtonBox = Box.createVerticalBox();
	private Box MenuListBox = Box.createVerticalBox();
	private Box OrderListBox = Box.createVerticalBox();
	private Box FoodMenuListBox = Box.createVerticalBox();
	
	private JPanel ContentsPanel;
	private JPanel CenterPanel;
	private JPanel BottomPanel;
	
	private JButton AddButton;
	private JButton RemoveButton;
	private JButton RemoveAllButton;
	private JButton CancelOrderButton;
	private JButton PayOrderButton;
	// TO DO: NewOrderButton: add another new order
	
	private JLabel MenuListLabel;
	private JLabel OrderListLabel;
	private JLabel SelectedMenuItemLabel;
	private JLabel SelectedOrderItemLabel;
	private JLabel SelectedMenuItemName;
	private JLabel SelectedOrderItemName;
	
	private JLabel CurrentTotalPriceLabel;
	private JLabel CurrentTotalPrice;
	private JLabel CurrentOrderIdLabel;
	private JLabel CurrentOrderId;
	private JLabel CurrentOrderStatusLabel;
	private JLabel CurrentOrderStatus;
	
	private JTextField CustomerNameField; 
	
	private JList<String> MenuItemList;
	private JList<String> OrderItemList;
	private JList<MenuItem> FoodMenuList;
	private JList<MenuItem> OrderList;
	
	// model elements	
	public DefaultListModel<String> DMenuItemList = new DefaultListModel<>();
	private DefaultListModel<String> DOrderItemList = new DefaultListModel<>();
	
	public ArrayList<MenuItem> CustomerPanelFoodMenu;
	public DefaultListModel<MenuItem> DFoodMenu = new DefaultListModel<MenuItem>();
	public JTable table;
	public DefaultTableModel tableModel;
	public ArrayList<Order> CustomerPanelOrders;
	
	public Customer CurrentCustomer;
	public Order CurrentOrder;

	/**
	 * Create the panel.
	 */
	public CustomerPanel() {
		
		// Create a BorderLayout.
		setLayout(new BorderLayout());		

		// Main contents
		ContentsPanel = new JPanel();
		ContentsPanel.setBorder(ContentBorder);
		ContentsPanel.setLayout(new BorderLayout());

		// Top region
		JLabel TitleLabel = new JLabel("Welcome! Please set up your order ...");
		TitleLabel.setFont(new Font(Font.DIALOG, Font.BOLD, 18));
		TitleLabel.setAlignmentX(CENTER_ALIGNMENT);
		TopRow1Box.add(TitleLabel);
		TopRow1Box.setBorder(BorderFactory.createEmptyBorder(0,250,0,200));
		TopBox.add(TopRow1Box);		
		TopBox.add(Box.createRigidArea(new Dimension(1,20)));
		
		//TopRow2Box.add(Box.createRigidArea(new Dimension(100,1)));
		TopRow2Box.setBorder(BorderFactory.createEmptyBorder(0,105,0,100));
		JLabel NoteLabel = new JLabel("Name: ");
		NoteLabel.setAlignmentX(LEFT_ALIGNMENT);
		CustomerNameField = new JTextField(10);
		CustomerNameField.setAlignmentX(LEFT_ALIGNMENT);
		TopRow2Box.add(NoteLabel);
		TopRow2Box.add(CustomerNameField);
		//TopRow2Box.add(Box.createRigidArea(new Dimension(100,1)));
		TopBox.add(TopRow2Box);
		TopBox.add(Box.createRigidArea(new Dimension(1,5)));
		ContentsPanel.add(TopBox, BorderLayout.NORTH);
		
		
		// Center region
		CenterPanel = new JPanel();
		CenterPanel.setBorder(CenterBorder);
		
		MenuListLabel = new JLabel("Menu:");
		MenuListLabel.setAlignmentX(LEFT_ALIGNMENT);
		
		InitMenuModel();
		MenuItemList = new JList<>(DMenuItemList);
		MenuItemList.setAlignmentX(LEFT_ALIGNMENT);
		MenuItemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		MenuItemList.setBorder(ListBorder);
		JScrollPane MenuListScroller = new JScrollPane(MenuItemList);
		MenuListScroller.setAlignmentX(LEFT_ALIGNMENT);
		MenuListScroller.setVerticalScrollBarPolicy(MenuListScroller.VERTICAL_SCROLLBAR_ALWAYS);
		//MenuListScroller.setSize(new Dimension(200, 300));
		SetSpecificSize(MenuListScroller, new Dimension(350, 460));
		MenuListBox.add(MenuListLabel);
		MenuListBox.add(MenuListScroller);
		CenterPanel.add(MenuListBox);
		CenterPanel.add(Box.createRigidArea(new Dimension(10,1)));
		
		FoodMenuList = new JList<>(DFoodMenu);
		JScrollPane FoodMenuListScroller = new JScrollPane(FoodMenuList);
		SetSpecificSize(MenuListScroller, new Dimension(350, 460));
		FoodMenuListBox.add(FoodMenuListScroller);
		//CenterPanel.add(FoodMenuListBox);
		//CenterPanel.add(Box.createRigidArea(new Dimension(10,1)));
		
		/* Table data try
		Object[][] data = {
				{"1", "John", "Doe"},
				{"2", "Jane", "Ever"}
		};
		String[] columns = {"ID", "First", "Last"};
		DefaultTableModel model = new DefaultTableModel(data,columns);
		*/
		String col[] = {"Name","Price"};
		tableModel = new DefaultTableModel(col, 0);		
		table = new JTable(tableModel);
		JScrollPane sp = new JScrollPane(table);
		//CenterPanel.add(sp);
		//CenterPanel.add(Box.createRigidArea(new Dimension(10,1)));
		
		AddButton = new JButton("Add Item >");
		RemoveButton = new JButton("< Remove Item");
		RemoveAllButton = new JButton("<< Remove All");
		CancelOrderButton = new JButton("Cancel Order");
		PayOrderButton = new JButton("Pay Order");
		
		//Dimension MaxButtonSize = RemoveAllButton.getMaximumSize();
		//SetSpecificSize(AddButton, MaxButtonSize);
		//SetSpecificSize(RemoveButton, MaxButtonSize);
		SetSpecificSize(AddButton, new Dimension(180,30));
		SetSpecificSize(RemoveButton, new Dimension(180,30));
		SetSpecificSize(RemoveAllButton, new Dimension(180,30));
		SetSpecificSize(CancelOrderButton, new Dimension(180,30));
		SetSpecificSize(PayOrderButton, new Dimension(180,30));
		
		ButtonBox.add(AddButton);
		ButtonBox.add(Box.createRigidArea(new Dimension(1,20)));
		ButtonBox.add(RemoveButton);
		ButtonBox.add(Box.createRigidArea(new Dimension(1,20)));
		ButtonBox.add(RemoveAllButton);
		ButtonBox.add(Box.createRigidArea(new Dimension(1,150)));
		//ButtonBox.add(CancelOrderButton);
		//ButtonBox.add(Box.createRigidArea(new Dimension(1,20)));
		ButtonBox.add(PayOrderButton);
		
		ButtonBox.add(Box.createRigidArea(new Dimension(1,10)));
		CurrentOrderIdLabel= new JLabel("Your Order ID:");
		CurrentOrderIdLabel.setAlignmentX(LEFT_ALIGNMENT);
		CurrentOrderId = new JLabel();
		CurrentOrderId.setAlignmentX(LEFT_ALIGNMENT);
		CurrentOrderStatusLabel= new JLabel("Your Order Status:");
		CurrentOrderStatusLabel.setAlignmentX(LEFT_ALIGNMENT);
		CurrentOrderStatus = new JLabel();
		CurrentOrderStatus.setAlignmentX(LEFT_ALIGNMENT);
		ButtonBox.add(CurrentOrderIdLabel);
		ButtonBox.add(CurrentOrderId);
		ButtonBox.add(Box.createRigidArea(new Dimension(1,5)));
		ButtonBox.add(CurrentOrderStatusLabel);
		ButtonBox.add(CurrentOrderStatus);
		
		CenterPanel.add(ButtonBox);
		CenterPanel.add(Box.createRigidArea(new Dimension(10, 1)));
		
		OrderListLabel = new JLabel("Your order:");
		OrderListLabel.setAlignmentX(LEFT_ALIGNMENT);
		OrderItemList = new JList<>(DOrderItemList);
		OrderItemList.setAlignmentX(LEFT_ALIGNMENT);
		OrderItemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		OrderItemList.setBorder(ListBorder);
		JScrollPane OrderListScroller = new JScrollPane(OrderItemList);
		OrderListScroller.setAlignmentX(LEFT_ALIGNMENT);
		OrderListScroller.setVerticalScrollBarPolicy(MenuListScroller.VERTICAL_SCROLLBAR_ALWAYS);
		//OrderListScroller.setSize(new Dimension(200, 300));
		SetSpecificSize(OrderListScroller, new Dimension(350, 460));
		OrderListBox.add(OrderListLabel);
		OrderListBox.add(OrderListScroller);
		CenterPanel.add(OrderListBox);
		CenterPanel.add(Box.createRigidArea(new Dimension(10,1)));		
		ContentsPanel.add(CenterPanel, BorderLayout.CENTER);
		
		// Bottom region
		BottomPanel = new JPanel();
		SelectedMenuItemLabel = new JLabel("Selected Item:");
		SelectedMenuItemLabel.setAlignmentX(LEFT_ALIGNMENT);
		SelectedMenuItemName = new JLabel();
		SelectedMenuItemName.setAlignmentX(LEFT_ALIGNMENT);
		SelectedOrderItemLabel = new JLabel("Ordered Item:");
		SelectedOrderItemLabel.setAlignmentX(LEFT_ALIGNMENT);
		SelectedOrderItemName = new JLabel();
		SelectedOrderItemName.setAlignmentX(LEFT_ALIGNMENT);
		BottomPanel.add(SelectedMenuItemLabel);
		BottomPanel.add(SelectedMenuItemName);
		BottomPanel.add(Box.createRigidArea(new Dimension(550,1)));
		//BottomPanel.add(SelectedOrderItemLabel);
		//BottomPanel.add(SelectedOrderItemName);
		CurrentTotalPriceLabel = new JLabel("Total Price:");
		CurrentTotalPriceLabel.setAlignmentX(LEFT_ALIGNMENT);
		CurrentTotalPrice = new JLabel();
		CurrentTotalPrice.setAlignmentX(LEFT_ALIGNMENT);
		BottomPanel.add(CurrentTotalPriceLabel);
		BottomPanel.add(CurrentTotalPrice);
		ContentsPanel.add(BottomPanel, BorderLayout.SOUTH);
		
		AddButton.addActionListener(this);
		RemoveButton.addActionListener(this);
		RemoveAllButton.addActionListener(this);
		CancelOrderButton.addActionListener(this);
		PayOrderButton.addActionListener(this);
		
		MenuItemList.addListSelectionListener(this);
		OrderItemList.addListSelectionListener(this);
		//ListBorder.addItemListener(this);

		add(ContentsPanel);
		
		InitCustomer();
		
	}
	
	public void InitCustomer() {
		CurrentCustomer = new Customer();
		CurrentOrder = new Order();
	}
	
	public void InitMenuModel() {
		DMenuItemList.clear();
		
		/* sample data for UI
		DMenuItemList.addElement("Apple");
		DMenuItemList.addElement("Banana");
		DMenuItemList.addElement("Cherry");		
		*/
	}
	
	private void SetSpecificSize(JComponent c, Dimension d) {
		c.setMinimumSize(d);
		c.setPreferredSize(d);
		c.setMaximumSize(d);
	}
	
	public void PopulateMenuList() {
		DFoodMenu = new DefaultListModel<MenuItem>();
	    for (MenuItem item : CustomerPanelFoodMenu) {
	    	DFoodMenu.addElement(item);
	    	DMenuItemList.addElement(item.GetNamePriceInfo());
	    }
	    FoodMenuList = new JList<>(DFoodMenu);
	}
	public void PopulateTableData() {
		MenuItem item = DFoodMenu.get(0);
		Object[] obj = {item.GetItemName(), item.GetItemPrice()};
		tableModel.addRow(obj);
		item = DFoodMenu.get(1);
		Object[] obj2 = {item.GetItemName(), item.GetItemPrice()};
		tableModel.addRow(obj2);
	}
	public void ClearSelectionData() {
		
	}
	
	
	@Override
	public void valueChanged(ListSelectionEvent e) {

		Object source = e.getSource();
		if (source == MenuItemList) {
			DisplaySelectedItems();
			return;
		}
		
	}
	public void DisplaySelectedItems() {
		String selectedItemName = MenuItemList.getSelectedValue();
		SelectedMenuItemName.setText(selectedItemName);
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		Object source = e.getSource();
		if (source == AddButton) {
			AddItem();
			return;
		}
		if (source == RemoveButton) {
			RemoveItem();
			return;
		}
		if (source == RemoveAllButton) {
			RemoveAll();
			return;
		}
		if (source == CancelOrderButton) {
			CancelOrder();
			return;
		}
		if (source == PayOrderButton) {
			PayOrder();
			return;
		}
		
	}
	
	private void AddItem() {
		int SelectedIdx = MenuItemList.getSelectedIndex();
		if (SelectedIdx == -1)
			return;
		
		String selectedItemName = MenuItemList.getSelectedValue();
		SelectedMenuItemName.setText(selectedItemName);
		 // DMenuItemList.removeElementAt(SelectedIdx);		
		
		ListModel<String> Orders =  OrderItemList.getModel();
		int OrderListCount = Orders.getSize();
		DOrderItemList.add(OrderListCount, selectedItemName);	
		SelectedOrderItemName.setText(selectedItemName);
		
		MenuItem selectedItem = GetItemByNamePrice(selectedItemName);
		CurrentOrder.AddToAllItems(selectedItem);
		double totalPrice = CurrentOrder.GetAllItemPrice();
		CurrentTotalPrice.setText("$ "+totalPrice);
		
		CurrentOrderId.setText("");
		CurrentOrderStatus.setText("Ordering ...");

	}
	private void RemoveItem() {
		int SelectedIdx = OrderItemList.getSelectedIndex();
		if (SelectedIdx == -1)
			return;
		
		String selectedItemName = OrderItemList.getSelectedValue();
		DOrderItemList.removeElementAt(SelectedIdx);
		//ListModel<String> Menu =  MenuItemList.getModel();
		//int MenuCount = Menu.getSize();
		//DMenuItemList.add(MenuCount, selectedItemName);		
		
		MenuItem selectedItem = GetItemByNamePrice(selectedItemName);
		CurrentOrder.DeleteFromAllItems(selectedItem);
		double totalPrice = CurrentOrder.GetAllItemPrice();
		CurrentTotalPrice.setText("$ "+totalPrice);
	}	
	private void RemoveAll() {		
		DOrderItemList.clear();
		SelectedOrderItemName.setText("");
		CurrentTotalPrice.setText("");
		InitMenuModel();
		PopulateMenuList();
		
		CurrentOrder = new Order();
		CurrentOrderId.setText("");
		CurrentOrderStatus.setText("");
	}
	
	
	private void PayOrder() {
				
		CurrentCustomer.SetName(CustomerNameField.getText());
		CurrentOrder.SetCustomer(CustomerNameField.getText());
		CurrentOrder.SetOrderStatus("Paid");
		CurrentTotalPrice.setText("$ 0.00");

		
		Order newOrder = new Order(CurrentOrder);
		int newOrderId = CustomerPanelOrders.size()+1;		
		newOrder.SetOrderId(newOrderId);
		CustomerPanelOrders.add(newOrder);
		//MainWindow.RestaurantOrders.add(CurrentOrder);
		
		CurrentOrderId.setText(""+newOrderId);
		CurrentOrderStatus.setText("Paid");
		
		// clear
		DOrderItemList.clear();
		SelectedOrderItemName.setText("");
		InitMenuModel();
		PopulateMenuList();
		CurrentOrder = new Order();
	}
	private void CancelOrder() {		
		DOrderItemList.clear();
		SelectedOrderItemName.setText("");
		CurrentTotalPrice.setText("");
		InitMenuModel();
		PopulateMenuList();
		
		CurrentOrder = new Order();
		CurrentOrder.SetOrderStatus("Ordering...");
	}
	
	private MenuItem GetItemByNamePrice(String namePrice) {

		MenuItem foundItem = new MenuItem();
		if (namePrice == null)
			return foundItem;
		
		//namePrice = "" + ItemName + " ($" + ItemPrice +")"
		int nameEndIdx = namePrice.indexOf("(");
		String name = namePrice.substring(0, nameEndIdx-1);
		int strLen = namePrice.length();
		String price = namePrice.substring(nameEndIdx+2, strLen-1);
		for (MenuItem item: CustomerPanelFoodMenu) {
			if (item.GetItemName().equals(name))
				foundItem = item;
		}
		return foundItem;
	}

	
}
