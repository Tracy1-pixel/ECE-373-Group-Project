import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.Border;

import ModelClasses.*;

public class StoreInfo extends JPanel {

	private static final long serialVersionUID = 1L;
	
	public Restaurant Store;
	
	private JRadioButton storeName;
	private Box verticalBox = Box.createVerticalBox();
	private Border ContentBorder = BorderFactory.createEmptyBorder(0,10,10,0);
	private JLabel storeLoc;
	private JTextArea storeHoursTextArea;

	/**
	 * Create the panel.
	 */
	public StoreInfo() {
		Store = new Restaurant();
	    
	    initComponents();
	}
	
	private void initComponents() {
		
		Store = MainWindow.MainRestaurant;
		
		
		// Create a GridLayout manager with
	    // four rows and one column.
	    setLayout(new GridLayout(1, 1));
	    
	    verticalBox.setAlignmentX(LEFT_ALIGNMENT);
	    verticalBox.setBorder(ContentBorder);
	    
	    verticalBox.add(Box.createVerticalStrut(20));
	    verticalBox.add(new JLabel("Fast Food Drive Thru"));
	    verticalBox.add(Box.createVerticalStrut(20));
	    
	    storeName = new JRadioButton("");
	    verticalBox.add(storeName);
	    storeLoc = new JLabel();
	    storeLoc.setBorder(BorderFactory.createEmptyBorder(10,20,10,0));
	    verticalBox.add(storeLoc);
	    
	    JLabel openHoursLabel = new JLabel("Open Hours:");
	    openHoursLabel.setBorder(BorderFactory.createEmptyBorder(10,20,10,0));
	    storeHoursTextArea = new JTextArea();	  
	    storeHoursTextArea.setAlignmentX(LEFT_ALIGNMENT);
	    storeHoursTextArea.setMinimumSize(new Dimension(330, 200));
	    storeHoursTextArea.setPreferredSize(new Dimension(330, 200));
	    storeHoursTextArea.setMaximumSize(new Dimension(330, 200));
	    storeHoursTextArea.setBorder(BorderFactory.createEmptyBorder(0,20,5,0));
	    verticalBox.add(openHoursLabel);
	    verticalBox.add(storeHoursTextArea);
	    
		
		// Add the radio buttons to this panel.
	    add(verticalBox);
	}
	
	public void PopulateStoreInfo(){
		storeName.setText("Name: " + Store.GetRestaurantName());
		storeLoc.setText("Location: " + Store.GetRestaurantLocation());
		
		/*
		ArrayList<String> openHours = new ArrayList<String>();
		openHours.add("Monday:    9AM - 9PM");
		openHours.add("Tuesday:   9AM - 9PM");
		openHours.add("Wednesday: 9AM - 9PM");
		openHours.add("Thursday:  9AM - 9PM");
		openHours.add("Friday:    9AM - 7PM");
		openHours.add("Saturday: 10AM - 5PM");
		openHours.add("Sunday:   11AM - 3PM");
		*/
		String storeHoursStr = "";
		
		//for(String i: openHours) {
		for (String i: Store.GetStoreHours()) {
			storeHoursStr = storeHoursStr + "\n" + i;
		}
		//System.out.print(storeHoursStr);
		storeHoursTextArea.setText(storeHoursStr);
	}
	

}
