
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.*;
import java.awt.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import ModelClasses.*;
import ModelClasses.MenuItem;
import DataClasses.*;


public class MainWindow extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel ContentPane;
	private static JTabbedPane TabbedPane;
	private static CustomerPanel CustomerTab;
	private static CashierPanel CashierTab;
	private static CookerPanel CookerTab;
	private static StoreInfo StoreTab;
	private static OrderInfo OrdersTab;
	
	public static Restaurant MainRestaurant;
	public static ArrayList<Employee> Employees;
	public static ArrayList<Customer> Customers;
	public static ArrayList<MenuItem> FoodMenu;
	public static ArrayList<Order> RestaurantOrders;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					MainWindow frame = new MainWindow();
					
					frame.setVisible(true);
					

					//PopulateData();
					RestaurantOrders = new ArrayList<>();
					Data1SimpleClass Data1 = new Data1SimpleClass();
					Data1.SetupData1();
					MainRestaurant = Data1.MainRestaurant;
					Employees = Data1.Employees;
					Customers = Data1.Customers;
					FoodMenu = Data1.FoodMenu;
					
					// Store info tab
					StoreTab.Store = MainRestaurant;
					StoreTab.PopulateStoreInfo();
					
					// Customer Tab
					CustomerTab.CustomerPanelFoodMenu = FoodMenu;	
					CustomerTab.CustomerPanelOrders	= RestaurantOrders; //references
				    CustomerTab.PopulateMenuList();
				    CustomerTab.PopulateTableData();
				    
				    // Cashier Tab
				    CashierTab.CashierPanelOrders = RestaurantOrders; //references
				    
				    // Cooker Tab
				    CookerTab.CookerPanelOrders	= RestaurantOrders; //references
				    
				    // Order Info Tab
				    OrdersTab.OrdersForSearch = RestaurantOrders; //references
				    OrdersTab.InitModelForOrdersInfoTab();
				    
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		
		setTitle("Fast-Food Drive-Thru Application");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		ContentPane = new JPanel();

		setSize(1100, 710);
		setResizable(true);
        setLocationRelativeTo(null); // Center the frame
		setContentPane(ContentPane);
        ContentPane.setLayout(null);
		
        // Create a JTabbedPane
        TabbedPane = new JTabbedPane();
        TabbedPane.setBounds(8, 10, 1070, 650);

        // Create content for Tab 1
        CustomerTab = new CustomerPanel();

        // Create content for Tab 2
        CashierTab = new CashierPanel();


        // Create content for Tab 3
        CookerTab = new CookerPanel();
        
        // Create content for Tab 4
        StoreTab = new StoreInfo();
     
        // Create content for Tab 4
        OrdersTab = new OrderInfo();

        // Add tabs to the JTabbedPane
        TabbedPane.addTab("Customer", CustomerTab);
        TabbedPane.addTab("Cashier", CashierTab);
        TabbedPane.addTab("Cooker", CookerTab);
        TabbedPane.addTab("Store Info", StoreTab);
        TabbedPane.addTab("Orders Info", OrdersTab);

        // Add the JTabbedPane to the JFrame
        getContentPane().add(TabbedPane, BorderLayout.CENTER);
        
        // populate data
        MainRestaurant = new Restaurant();   
		Employees = new ArrayList<Employee>();
		Customers = new ArrayList<Customer>();
		FoodMenu = new ArrayList<MenuItem>();
		
		TabbedPane.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int selectedIndex = TabbedPane.getSelectedIndex();
                if (selectedIndex == 0) { // CustomerTab tab header is clicked
                    // Populate data for CustomerTab
                    //System.out.println("CustomerTab is selected.");
                } else if (selectedIndex == 1) { // CashierTab
                    //System.out.println("CashierTab selected.");
                    CashierTab.PopulateOrderList();
                    CashierTab.ClearSelectedData();
                } else if (selectedIndex == 2) { // CookerTab
                    //System.out.println("CookerTab selected.");
                    CookerTab.PopulateOrderList();
                    CookerTab.ClearSelectedData();
                } else if (selectedIndex == 3) { // StoreTab
                    //System.out.println("StoreTab selected.");
                } else if (selectedIndex == 4) { // OrdersTab
                    //System.out.println("OrdersTab selected.");
                	OrdersTab.InitModelForOrdersInfoTab();
                }
            }
        });

	}
	
	public static Order GetOrderById(String oID) {
		Order selectedOrder = new Order();
		for (Order o: MainWindow.RestaurantOrders) {
			if (Integer.toString(o.GetOrderId()).equals(oID))
				selectedOrder = o;
		}
		return selectedOrder;
	}
	
	
	// for testing ...
	public static void PopulateData() {
		MainRestaurant.SetRestaurantId(1);
		MainRestaurant.SetRestaurantName("Main Restaurant");
		
		//MenuItem(String name, String dsrpt, double price, String type)
		MenuItem MenuItem11 = new MenuItem("Hamburger", "Standard Burger", 3.00, "food");
		FoodMenu.add(MenuItem11);
		MenuItem MenuItem12 = new MenuItem("CheeseBurger", "Cheese Burger", 3.50, "food");
		FoodMenu.add(MenuItem12);
		MenuItem MenuItem13 = new MenuItem("VeggieBurger", "Veggie Burger", 3.50, "food");
		FoodMenu.add(MenuItem13);
		MenuItem MenuItem14 = new MenuItem("ButterBurger", "Butter Burger", 3.50, "food");
		FoodMenu.add(MenuItem14);
		MenuItem MenuItem15 = new MenuItem("ChichenBurger", "Chichen Burger", 3.50, "food");
		FoodMenu.add(MenuItem15);
		MenuItem MenuItem16 = new MenuItem("Fries", "Fries", 1.50, "food");
		FoodMenu.add(MenuItem16);
		MenuItem MenuItem17 = new MenuItem("Nuggets", "Chichen Nuggets", 2.20, "food");
		FoodMenu.add(MenuItem17);
		MenuItem MenuItem21 = new MenuItem("Tea", "Iced Tea", 1.50, "drink");
		FoodMenu.add(MenuItem21);
		MenuItem MenuItem22 = new MenuItem("Soda", "Soda", 1.50, "drink");
		FoodMenu.add(MenuItem22);
		MenuItem MenuItem23 = new MenuItem("Water", "Water with ice", 0.00, "drink");
		FoodMenu.add(MenuItem23);
		
		Manager Manager1 = new Manager();
		Manager1.SetEmployId(100);
		Manager1.SetName("Bob");
		Employees.add(Manager1);
		
		Cashier Cashier1 = new Cashier();
		Cashier1.SetEmployId(101);
		Cashier1.SetName("Smith");
		Employees.add(Cashier1);
		
		Cooker Cooker1 = new Cooker();
		Cooker1.SetEmployId(102);
		Cooker1.SetName("Chief");
		Employees.add(Cooker1);
		
		MainRestaurant.SetEmployees(Employees);
		MainRestaurant.SetFoodMenu(FoodMenu);
	}

}
