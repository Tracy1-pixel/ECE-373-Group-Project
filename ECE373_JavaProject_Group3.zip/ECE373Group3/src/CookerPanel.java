

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.Border;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import ModelClasses.Item;
import ModelClasses.MenuItem;
import ModelClasses.Order;


public class CookerPanel extends JPanel 
	implements ActionListener, ItemListener, ListSelectionListener {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	// UI elements
	private Border CenterBorder = BorderFactory.createEmptyBorder(10,10,10,10);
	private Border ContentBorder = BorderFactory.createEmptyBorder(0,0,10,0);
	private Border ListBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1);
	private Border WestBorder = BorderFactory.createEmptyBorder(10,50,10,10);
	
	private Box TopBox = Box.createVerticalBox();
	private Box CenterBox = Box.createVerticalBox();
	private Box BottomBox = Box.createVerticalBox();
	private Box OrderListBox = Box.createVerticalBox();
	private Box OrderBox = Box.createVerticalBox();
	private Box ButtonBox = Box.createVerticalBox();

	
	private JPanel ContentsPanel;
	private JPanel TopPanel;
	private JPanel WestPanel;
	private JPanel CenterPanel;
	private JPanel ButtonPanel;
	
	private JButton StartPreparingButton;
	private JButton ReadyToPickupButton;
	private JButton PickupButton;
	
	private JLabel OrdersLabel = new JLabel("Orders:");
	private JLabel SelectedOrderLabel = new JLabel("Selected Order:");
	private JLabel SelectedOrderInfo = new JLabel();
	private JLabel SelectedOrderStatusLabel = new JLabel("Selected Order Status:");
	private JLabel SelectedOrderStatusInfo = new JLabel();

	public JFrame dialogFrame = new JFrame();
	
	private JList<String> OrderList;
	public DefaultListModel<String> DOrderList = new DefaultListModel<>();
	private JList<String> OrderInfoList;
	public DefaultListModel<String> DOrderInfoList = new DefaultListModel<>();
	   
	public ArrayList<Order> CookerPanelOrders = new ArrayList<>();
	public Order SelectedOrder = new Order();
	   

	/**
	 *  Constructor
	 */
	public CookerPanel()
	{
		// Create a BorderLayout.
		setLayout(new BorderLayout());	
		
		// Main contents
		ContentsPanel = new JPanel();
		ContentsPanel.setBorder(ContentBorder);
		ContentsPanel.setLayout(new BorderLayout());
		
		// Top region
		JLabel TitleLabel = new JLabel("Welcome!");
		TitleLabel.setFont(new Font(Font.DIALOG, Font.BOLD, 18));
		TitleLabel.setAlignmentX(CENTER_ALIGNMENT);
		TopBox.add(TitleLabel);
		TopBox.add(Box.createRigidArea(new Dimension(1,10)));
		ContentsPanel.add(TopBox, BorderLayout.NORTH);
		
		// Center region
		PopulateOrderList();
		

		WestPanel = new JPanel();
		WestPanel.setBorder(WestBorder);
		WestPanel.setLayout(new BoxLayout(WestPanel, BoxLayout.Y_AXIS));
		
		OrdersLabel.setAlignmentX(LEFT_ALIGNMENT);
		OrderList = new JList<>(DOrderList);
		OrderList.setAlignmentX(LEFT_ALIGNMENT);
		OrderList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		OrderList.setBorder(ListBorder);
		JScrollPane OrderListScroller = new JScrollPane(OrderList);
		OrderListScroller.setAlignmentX(LEFT_ALIGNMENT);
		OrderListScroller.setVerticalScrollBarPolicy(OrderListScroller.VERTICAL_SCROLLBAR_ALWAYS);
		SetSpecificSize(OrderListScroller, new Dimension(350, 520));
		OrderListBox.add(Box.createVerticalStrut(5));
		OrderListBox.add(OrdersLabel);
		OrderListBox.add(OrderListScroller);
		WestPanel.add(OrderListBox);
		ContentsPanel.add(WestPanel, BorderLayout.WEST);
		
		CenterPanel = new JPanel();
		CenterPanel.setBorder(CenterBorder);
		//CenterPanel.setLayout(new BoxLayout(CenterPanel, BoxLayout.Y_AXIS));
		
		SelectedOrderLabel.setAlignmentX(LEFT_ALIGNMENT);
		SelectedOrderInfo.setAlignmentX(LEFT_ALIGNMENT);
		//JScrollPane OrderScroller = new JScrollPane(SelectedOrderInfo);
		OrderInfoList = new JList<String>(DOrderInfoList);
		OrderInfoList.setAlignmentX(LEFT_ALIGNMENT);
		//OrderInfoList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		OrderInfoList.setBorder(ListBorder);
		JScrollPane OrderScroller = new JScrollPane(OrderInfoList);
		OrderScroller.setAlignmentX(LEFT_ALIGNMENT);
		OrderScroller.setVerticalScrollBarPolicy(OrderScroller.VERTICAL_SCROLLBAR_ALWAYS);
		SetSpecificSize(OrderScroller, new Dimension(350, 500));		
		OrderBox.add(SelectedOrderLabel);
		OrderBox.add(OrderScroller);
		//OrderBox.setBorder(BorderFactory.createEmptyBorder(0,0,50,0));
		
		SelectedOrderStatusLabel.setAlignmentX(LEFT_ALIGNMENT);
		SelectedOrderStatusInfo.setAlignmentX(LEFT_ALIGNMENT);
		OrderBox.add(SelectedOrderStatusLabel);
		OrderBox.add(SelectedOrderStatusInfo);
		
		CenterPanel.add(OrderBox);
		CenterPanel.add(Box.createRigidArea(new Dimension(10, 1)));
		
		StartPreparingButton = new JButton("Start Preparing");
		ReadyToPickupButton = new JButton("Ready for Pickup");
		PickupButton = new JButton("Pickup Order");
		SetSpecificSize(StartPreparingButton, new Dimension(180,30));
		SetSpecificSize(ReadyToPickupButton, new Dimension(180,30));
		SetSpecificSize(PickupButton, new Dimension(180,30));	
				
		ButtonBox.add(StartPreparingButton);
		ButtonBox.add(Box.createVerticalStrut(10));
		ButtonBox.add(ReadyToPickupButton);
		ButtonBox.add(Box.createVerticalStrut(180));
		ButtonBox.add(PickupButton);
		CenterPanel.add(ButtonBox);

				
		/*
		ButtonPanel = new JPanel();
		ButtonPanel.setBorder(CenterBorder);
		ButtonPanel.setLayout(new BoxLayout(ButtonPanel, BoxLayout.X_AXIS));		

		ButtonPanel.add(Box.createHorizontalGlue());
		ButtonPanel.add(StartPreparingButton);
		ButtonPanel.add(Box.createHorizontalStrut(10)); 
		ButtonPanel.add(ReadyToPickupButton);
		ButtonPanel.add(Box.createHorizontalStrut(10)); 
		ButtonPanel.add(PickupButton);
		ButtonPanel.add(Box.createHorizontalGlue());
		CenterPanel.add(ButtonPanel);
		*/
		
				
		ContentsPanel.add(CenterPanel, BorderLayout.CENTER);
		

		StartPreparingButton.addActionListener(this);
		ReadyToPickupButton.addActionListener(this);
		PickupButton.addActionListener(this);

		OrderList.addListSelectionListener(this);
		
		add(ContentsPanel);
		
		dialogFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dialogFrame.setSize(200, 150);

	}
	public void PopulateOrderList() {
		DOrderList.clear();
		if (CookerPanelOrders == null)
			return;
		
	    for (Order item : CookerPanelOrders) {
	    	DOrderList.addElement(item.GetOrderIdStatus());
	    }
	}
	public void ClearSelectedData() {
		SelectedOrder = new Order();
		DOrderInfoList.clear();
		SelectedOrderStatusInfo.setText("");
	}
	
	private void SetSpecificSize(JComponent c, Dimension d) {
		c.setMinimumSize(d);
		c.setPreferredSize(d);
		c.setMaximumSize(d);
	}
	

	@Override
	public void valueChanged(ListSelectionEvent e) {
	 // TODO Auto-generated method stub
		Object source = e.getSource();
		if (source == OrderList || source.equals(OrderList) ||
				source.getClass() == OrderList.getClass()) {
			DisplaySelectedOrder();
			return;
		}	
	}
	public void DisplaySelectedOrder() {
	    String selectedDisplayOrder = OrderList.getSelectedValue();
	    if (selectedDisplayOrder == null)
	        return;

	    int orderIdEndIdx = selectedDisplayOrder.indexOf("[");
	    String orderId = selectedDisplayOrder.substring(8, orderIdEndIdx - 1);
	    SelectedOrder = MainWindow.GetOrderById(orderId);

	    DOrderInfoList.clear();

	 
	    ArrayList<String> itemNames = new ArrayList<>();
	    ArrayList<Integer> itemQty = new ArrayList<>();

	    for (Item i : SelectedOrder.GetAllItems()) {
	        String info = i.GetItemNameQty();

	
	        String name = info;
	        int nameStart = info.indexOf("Name=");
	        int qtyPos = info.indexOf(", Qty");
	        if (nameStart >= 0 && qtyPos > nameStart) {
	            nameStart += "Name=".length();
	            name = info.substring(nameStart, qtyPos);
	        }


	        int index = itemNames.indexOf(name);
	        if (index == -1) {
	            itemNames.add(name);
	            itemQty.add(1);
	        } else {
	            itemQty.set(index, itemQty.get(index) + 1);
	        }
	    }


	    for (int i = 0; i < itemNames.size(); i++) {
	        String line = "food: Name=" + itemNames.get(i) + ", Qty=" + itemQty.get(i);
	        DOrderInfoList.addElement(line);
	    }

	    SelectedOrderStatusInfo.setText(SelectedOrder.GetOrderStatus());
	}


	
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		
	}

	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == StartPreparingButton) {
			StartToPrepare();
			return;
		}
		if (source == ReadyToPickupButton) {
			ReadyToPickup();
			return;
		}
		if (source == PickupButton) {
			Pickup();
			return;
		}
	}
	
	public void StartToPrepare() {
		String orderStatus = SelectedOrder.GetOrderStatus();
		if (orderStatus.equals("Ready to cook")){
			this.SelectedOrder.SetOrderStatus("Preparing");
			
			PopulateOrderList();
			SelectedOrderStatusInfo.setText(SelectedOrder.GetOrderStatus());
		}
		else {
			JOptionPane.showMessageDialog(dialogFrame, 
					"Sorry, only 'Ready to cook' order can be set to 'Preparing'.", 
					"Warning", JOptionPane.WARNING_MESSAGE);
		}
	}
	public void ReadyToPickup() {

		String orderStatus = SelectedOrder.GetOrderStatus();
		if (orderStatus.equals("Preparing")){
			this.SelectedOrder.SetOrderStatus("Ready for Pickup");
			
			PopulateOrderList();
			SelectedOrderStatusInfo.setText(SelectedOrder.GetOrderStatus());	
		}
		else {
			JOptionPane.showMessageDialog(dialogFrame, 
					"Sorry, only 'Preparing' order can be set to 'Ready for Pickup'.", 
					"Warning", JOptionPane.WARNING_MESSAGE);			
		}
	}
	public void Pickup() {

		String orderStatus = SelectedOrder.GetOrderStatus();
		if (orderStatus.equals("Ready for Pickup")){
	
			this.SelectedOrder.SetOrderStatus("Picked up");
			
			PopulateOrderList();
			SelectedOrderStatusInfo.setText(SelectedOrder.GetOrderStatus());		
		}
		else {
			JOptionPane.showMessageDialog(dialogFrame, 
					"Sorry, only 'Ready for Pickup' order can be set to 'Picked up'.", 
					"Warning", JOptionPane.WARNING_MESSAGE);			
		}
	}
	
}
